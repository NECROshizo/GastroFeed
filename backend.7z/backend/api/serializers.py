
from rest_framework import serializers
from djoser import serializers as djoser_serializers
# .serializers import UserCreateSerializer, UserSerializer
from django.db.models import F
from django.contrib.auth import get_user_model
from food.models import (
    Tag,
    Ingredients,
    Recipes,
    IngredientsRecipes,
)


User = get_user_model()


class UserCreateSerializer(djoser_serializers.UserCreateSerializer):

    class Meta:
        model = User
        fields = ('email', 'username', 'first_name', 'last_name', 'password')


class UserSerializer(djoser_serializers.UserSerializer):
    class Meta:
        model = User
        fields = ('email', 'username', 'first_name', 'last_name')


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ('id', 'name', 'color', 'slug',)


class IngredientsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingredients
        fields = ('id', 'name', 'measurement_unit', )

# class IngredientsRecipesSerializer(serializers.ModelSerializer):
#     id = serializers.SlugRelatedField(

#     )
#     class Meta:
#         model = IngredientsRecipes
#         fields = ('id', 'name', 'measurement_unit', 'amount' )


class RecipesSerializer(serializers.ModelSerializer):
    tags = TagSerializer(many=True,)
    author = UserSerializer(read_only=True,)
    ingredients = serializers.SerializerMethodField()

    class Meta:
        model = Recipes
        fields = (
            'id',
            'tags',
            'author',
            'ingredients',
            # 'is_favorited',
            # 'is_in_shopping_cart',
            'image',
            'text',
            'cooking_time',
        )

    def get_ingredients(self, obj: Recipes):
        ingredients = obj.ingredients.values(
            'id', 'name', 'measurement_unit',
            amount=F('ingredient_in_recipe__amount')
        )
        return ingredients
